
import numpy as np

# 1.1
print("\nЗадание 1.1\n")

numbers = np.array([0.1, 0.2, 0.3], dtype=np.float32)
result = np.sum(numbers)

print("Массив:", numbers)
print("Полученная сумма:", result)
print("Ожидаемая сумма:", 0.6)
print("Погрешность:", float(result) - 0.6)


# 1.2
print("\nЗадание 1.2\n")

print("Эпсилон float32:", np.finfo(np.float32).eps)
print("Эпсилон float64:", np.finfo(np.float64).eps)


# 1.3
print("\nЗадание 1.3\n")

a = np.float32(100000000)
b = np.float32(100000001)

print("a =", a)
print("b =", b)
print("Разность float32:", b - a)
print("Разность float64:", np.float64(100000001) - np.float64(100000000))
