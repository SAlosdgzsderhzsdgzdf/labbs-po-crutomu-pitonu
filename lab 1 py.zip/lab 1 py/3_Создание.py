
import numpy as np

# 3.1
print("\nЗадание 3.1\n")

file = np.memmap(
    "mass.dat",
    dtype=np.float64,
    mode="w+",
    shape=(1000, 1000)
)

file[:] = np.random.random((1000, 1000))
file.flush()

print("Файл создан")
print("Первые элементы:", file[0, :5])

del file
