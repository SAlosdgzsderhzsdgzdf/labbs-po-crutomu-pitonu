
import numpy as np
import timeit

# 3.2
print("\nЗадание 3.2\n")

data = np.memmap(
    "mass.dat",
    dtype=np.float64,
    mode="r",
    shape=(1000, 1000)
)

row = data[200, :]
column = data[:, 300]

print("Строка массива:\n", row)
print("\nСтолбец массива:\n", column)


# 3.3
print("\nЗадание 3.3\n")

row_time = timeit.timeit(
    "for i in range(1000): data[i, :].sum()",
    globals=globals(),
    number=10
) / 10

column_time = timeit.timeit(
    "for i in range(1000): data[:, i].sum()",
    globals=globals(),
    number=10
) / 10

print(f"Время обхода строк: {row_time * 1000:.2f} мс")
print(f"Время обхода столбцов: {column_time * 1000:.2f} мс")

if row_time > 0:
    print("Отношение времени:", column_time / row_time)

del data
