
import numpy as np
import time
from scipy.sparse import random as sparse_random

# 4.1
print("\nЗадание 4.1\n")

while True:
    matrix = sparse_random(5, 5, density=0.2, format="csr")
    if matrix.nnz == 5:
        break

print(matrix.toarray())
print("Количество ненулевых элементов:", matrix.nnz)


# 4.2
print("\nЗадание 4.2\n")

matrix_coo = matrix.tocoo()
matrix_csc = matrix.tocsc()

print("Формат COO:\n", matrix_coo)
print("\nФормат CSC:\n", matrix_csc)


# 4.3
print("\nЗадание 4.3\n")

vector = np.array([2, 4, 6, 8, 10])
result = matrix.dot(vector)

print("Исходный вектор:", vector)
print("Результат:", result)


# 4.4
print("\nЗадание 4.4\n")

sparse_matrix = sparse_random(
    1000, 1000,
    density=0.01,
    format="csr"
)

dense_matrix = sparse_matrix.toarray()
vector = np.random.random(1000)

start = time.time()
result_sparse = sparse_matrix.dot(vector)
time_sparse = time.time() - start

start = time.time()
result_dense = dense_matrix.dot(vector)
time_dense = time.time() - start

print("Время разреженной матрицы:", time_sparse)
print("Время плотной матрицы:", time_dense)

print("Разница:", time_dense - time_sparse)
