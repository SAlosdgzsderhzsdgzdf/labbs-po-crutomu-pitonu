
import random
import time
import pyximport

# 5.1
print("\nЗадание 5.1\n")

values = [2, 3, 4, 5, 6]
total = 0

for number in values:
    total += number ** 2

print("Сумма квадратов:", total)


# 5.2
print("\nЗадание 5.2\n")

pyximport.install()
import helpme

cython_result = helpme.summm(values)

print("Результат Cython:", cython_result)


# 5.3
print("\nЗадание 5.3\n")

N = 10000000
numbers = [random.randint(1, 100) for i in range(N)]

total = 0

start = time.perf_counter()

for number in numbers:
    total += number * number

python_time = time.perf_counter() - start

start = time.perf_counter()

cython_result = helpme.summm(numbers)

cython_time = time.perf_counter() - start

print("Результат Python:", total)
print("Время Python:", python_time)

print("Результат Cython:", cython_result)
print("Время Cython:", cython_time)

if cython_time > 0:
    print("Ускорение:", python_time / cython_time)
