
def summm(list values):
    cdef long long result = 0
    cdef int number

    for number in values:
        result += number * number

    return result
