
import numpy as np
import random

# 2.1
print("\nЗадание 2.1\n")

A = np.array([
    [random.randint(-10, 15) for j in range(5)]
    for i in range(4)
])

print("Матрица A:\n", A)

print("\nВторая строка:")
print(A[1, :])

print("\nСтолбец с индексом 3:")
print(A[:, 3])

print("\nПодмассив:")
print(A[1:4, 2:5])


# 2.2
print("\nЗадание 2.2\n")

rows = [0, 2, 3]
columns = [1, 4]

selected = A[np.ix_(rows, columns)]
print(selected)


# 2.3
print("\nЗадание 2.3\n")

A[A < 0] = 0
print("Матрица после изменений:\n", A)


# 2.4
print("\nЗадание 2.4\n")

B = np.array([[2], [4], [6], [8]])
C = np.array([[10, 20, 30, 40, 50]])

answer = B + C

print("Массив B:\n", B)
print("Массив C:\n", C)
print("Результат сложения:\n", answer)
print("Размер результата:", answer.shape)
